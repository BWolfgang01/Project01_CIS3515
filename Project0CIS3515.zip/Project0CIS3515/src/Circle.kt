import kotlin.math.PI
import kotlin.math.pow

class Circle(_name: String) : Shape(_name) {
    var radius : Double = 0.0

    override fun setDimensions(radius: Double, side2: Double, side3: Double){
        this.radius = radius
    }

    override fun printDimensions() {
        println("This shape has a radius of ${this.radius}")
    }

    override fun getArea(): Double {
        return PI * radius.pow(2)
    }
}