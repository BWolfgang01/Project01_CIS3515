interface Dimensionable {
    fun printDimensions()
}