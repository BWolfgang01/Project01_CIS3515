import kotlin.math.sqrt

class EquilateralTriangle (_name: String) : Triangle(_name) {
    var side : Double = 0.0

    override fun setDimensions(side: Double, side2: Double, side3: Double){
        this.side = side
    }

    override fun printDimensions() {
        println("This shape has 3 sides of equal length ${this.side}")
    }

    override fun getArea(): Double {
        var s = side*3/2
        return sqrt(s*((s-side)*(s-side)*(s-side)))
    }
}