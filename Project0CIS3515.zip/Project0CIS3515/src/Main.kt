import java.util.Scanner

fun printStuff(thing : Shape){
    println("\nThe name of the ${thing::class.simpleName} is ${thing.name}")
    thing.printDimensions()
    println("The area of the ${thing::class.simpleName} is ${thing.getArea()}\n")
}

fun main() {
    var mySquare : Shape = Square("myFirstSquare")
    var myCircle : Shape = Circle("myFirstCircle")
    var myTriangle : Shape = Triangle("myFirstTriangle")
    var myEquilateralTriangle = EquilateralTriangle("myFirstEquilateralTriangle")

    val reader = Scanner(System.`in`)
    print("Enter the length for the square: ")
    var usersInput:Double = reader.nextDouble()
    print("Enter the height for the square: ")
    var usersInput2 = reader.nextDouble()

    mySquare.setDimensions(usersInput, usersInput2)

    print("Enter the radius for the circle: ")
    usersInput = reader.nextDouble()

    myCircle.setDimensions(usersInput)

    print("Enter the length of the first side of the triangle: ")
    usersInput = reader.nextDouble()
    print("Enter the length of the second side of the triangle: ")
    usersInput2 = reader.nextDouble()
    print("Enter the length of the third side of the triangle: ")
    var usersInput3 = reader.nextDouble()

    myTriangle.setDimensions(usersInput, usersInput2, usersInput3)

    print("Enter the length for the side of the equilateral triangle: ")
    usersInput = reader.nextDouble()

    myEquilateralTriangle.setDimensions(usersInput)

    printStuff(mySquare)
    printStuff(myCircle)
    printStuff(myTriangle)
    printStuff(myEquilateralTriangle)
}