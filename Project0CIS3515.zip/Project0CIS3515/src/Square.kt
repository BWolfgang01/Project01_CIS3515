class Square(_name: String) : Shape(_name) {
    var length : Double = 0.0
    var height : Double = 0.0

    override fun setDimensions(length: Double, height: Double, side3: Double) {
        this.length = length
        this.height = height
    }

    override fun printDimensions() {
        println("This shape has a length of ${this.length} and height of ${this.height}")
    }

    override fun getArea() : Double{
        return this.length * this.height
    }
}